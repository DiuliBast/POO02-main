import java.util.Scanner;

public class BancodeMidias {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
    }
}
